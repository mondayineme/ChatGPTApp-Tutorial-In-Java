package com.example.chatgptapptutorial;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MessageAdapter extends RecyclerView.Adapter<MessageAdapter.MessageViewHolder> {
    private List<MessageModel> messageModelList;
    private Context mContext;

    public MessageAdapter(List<MessageModel> messageModelList, Context mContext) {
        this.messageModelList = messageModelList;
        this.mContext = mContext;
    }

    @NonNull
    @Override
    public MessageAdapter.MessageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View chatView = LayoutInflater.from(mContext).inflate(R.layout.chat_item_layout, parent, false);
        return new MessageViewHolder(chatView);
    }

    @Override
    public void onBindViewHolder(@NonNull MessageAdapter.MessageViewHolder holder, int position) {
        MessageModel messageModel = messageModelList.get(position);

        if (messageModel.getSendBy().equals(MessageModel.SEND_BY_ME)){
            // Layouts Visibility
            holder.layoutChatGPTReceiver.setVisibility(View.GONE);
            holder.layoutMeSender.setVisibility(View.VISIBLE);

            // Getting of messages
            holder.textViewMeSender.setText(messageModel.getMessage());
        }else{
            // Layouts Visibility
            holder.layoutMeSender.setVisibility(View.GONE);
            holder.layoutChatGPTReceiver.setVisibility(View.VISIBLE);

            // Getting of messages
            holder.textViewChatGPTReceiver.setText(messageModel.getMessage());
        }
    }

    @Override
    public int getItemCount() {
        return messageModelList.size();
    }

    public class MessageViewHolder extends RecyclerView.ViewHolder {
        LinearLayout layoutChatGPTReceiver, layoutMeSender;
        TextView textViewChatGPTReceiver, textViewMeSender;

        public MessageViewHolder(@NonNull View itemView) {
            super(itemView);

            layoutChatGPTReceiver = itemView.findViewById(R.id.receiver_chat_layout);
            layoutMeSender = itemView.findViewById(R.id.sender_chat_layout);

            textViewChatGPTReceiver = itemView.findViewById(R.id.receiver_chat_text);
            textViewMeSender = itemView.findViewById(R.id.sender_chat_text);
        }
    }
}
