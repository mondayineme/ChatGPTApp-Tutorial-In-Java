package com.example.chatgptapptutorial;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerViewChat;
    private ImageButton imageButtonSend;
    private EditText editTextEnterText;
    private TextView textViewWelcomeTxt;

    
    private List<MessageModel> messageModelList;
    private MessageAdapter messageAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerViewChat = findViewById(R.id.recycler_view);
        imageButtonSend = findViewById(R.id.btn_send);
        editTextEnterText = findViewById(R.id.messageEdt);
        textViewWelcomeTxt = findViewById(R.id.txt_welcome_txt);

        messageModelList = new ArrayList<>();

        // recyclerView
        messageAdapter = new MessageAdapter(messageModelList, this);
        recyclerViewChat.setAdapter(messageAdapter);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setStackFromEnd(true);
        recyclerViewChat.setLayoutManager(layoutManager);

        imageButtonSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String question = editTextEnterText.getText().toString().trim();
                AddToChat(question, MessageModel.SEND_BY_ME);
                editTextEnterText.setText("");
                callApi(question);
                textViewWelcomeTxt.setVisibility(View.GONE);
            }
        });

    }

    public void AddToChat(String message, String sendBy){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                messageModelList.add(new MessageModel(message, sendBy));
                recyclerViewChat.smoothScrollToPosition(messageAdapter.getItemCount());
            }
        });
    }

    public void AddResponse(String response){
        //messageModelList.remove(messageModelList.size()-1);
        AddToChat(response, MessageModel.SEND_BY_BOT);
    }

    public void callApi(String mQuestion){

        //messageModelList.add(new MessageModel("Typing...", MessageModel.SEND_BY_BOT));

         // Params
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("model", "text-davinci-003");
            jsonObject.put("prompt", mQuestion);
            jsonObject.put("max_tokens", 4000);
            jsonObject.put("temperature", 0);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        // OkHTTP Init
        MediaType JSON = MediaType.get("application/json; charset=utf-8");
        OkHttpClient client = new OkHttpClient();

        // OkHTTP Request
        RequestBody body = RequestBody.create(jsonObject.toString(), JSON);
        Request request = new Request.Builder()
                .url("https://api.openai.com/v1/completions")
                .header("Authorization", "Bearer apiKeyhere")
                .post(body)
                .build();

        // Enqueue
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                AddResponse("Failed to load message due to "+e.getMessage());
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful()){
                    try {
                        // Callback response
                        JSONObject objectResponse = new JSONObject(response.body().string());
                        JSONArray jsonArray = objectResponse.getJSONArray("choices");
                        String result = jsonArray.getJSONObject(0).getString("text");
                        AddResponse(result.trim());
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }else{
                    AddResponse("Failed to load message due to "+response.body().string());
                }
            }
        });

    }
}